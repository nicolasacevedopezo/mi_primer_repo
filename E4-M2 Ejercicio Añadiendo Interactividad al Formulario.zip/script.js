const form = document.getElementById('contact-form');
const feedbackContainer = document.getElementById('feedback-message');
const inputNombre = document.getElementById('nombre');
const inputEmail = document.getElementById('email');
const textareaMensaje = document.getElementById('mensaje');

function handleFormSubmit(event) {
    event.preventDefault(); 
    const nombre = inputNombre.value.trim();
    const email = inputEmail.value.trim();
    const mensaje = textareaMensaje.value.trim();
    feedbackContainer.innerHTML = ''; 
    if (nombre === '' || email === '') {
        feedbackContainer.innerHTML = `
            <div class="alert alert-danger" role="alert">
             Porfavor llenar todos los campos.
            </div>
        `;
    } else {
        feedbackContainer.innerHTML = `
            <div class="alert alert-success" role="alert">
                Gracias, ${nombre} te contataré pronto.
            </div>
        `;
        form.reset(); 
    }
}

if (form) {
    form.addEventListener('submit', handleFormSubmit);
} else {
    console.error("Error: El formulario con ID 'contact-form' no fue encontrado.");
}